package com.yienx.imperial.court.service.api;

import com.yienx.imperial.court.entity.Emp;

/**
 * @Date 2022/4/19
 * @Author YiENx
 * @Description
 */
public interface EmpService {

    Emp getEmpByLogin(String loginAccount, String loginPassword);



}
